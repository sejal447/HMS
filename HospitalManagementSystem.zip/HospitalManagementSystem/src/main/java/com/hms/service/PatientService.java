package com.hms.service;

import com.hms.entity.Patient;
import java.util.List;

public interface PatientService {
    Patient addPatient(Patient patient);
    Patient updatePatient(Long id, Patient patient);
    Patient getPatientById(Long id);
    List<Patient> getAllPatients();
    void deletePatient(Long id);
}
