package com.hms.service;

import com.hms.entity.Doctor;
import java.util.List;

public interface DoctorService {
    Doctor addDoctor(Doctor doctor);
    Doctor updateDoctor(Long id, Doctor doctor);
    Doctor getDoctorById(Long id);
    List<Doctor> getAllDoctors();
    void deleteDoctor(Long id);
}
