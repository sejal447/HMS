export class Patient {
    id: number = 0;
    name: string = "";
    age: number = 0;
    blood: string = "";
    prescription: string = "";
    dose: string = "";
    fees: string = "";
    urgency: string = "";

}
